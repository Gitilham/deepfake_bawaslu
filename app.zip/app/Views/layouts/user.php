<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Dashboard User') ?></title>

    <link rel="icon" href="<?= base_url('favicon.ico') ?>">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        :root {
            --user-red: #b31312;
            --user-red-2: #e63946;
            --user-dark: #111827;
            --user-muted: #6b7280;
            --user-border: #e5e7eb;
            --user-bg: #f3f4f6;
            --sidebar-width: 282px;
            --topbar-height: 78px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background:
                radial-gradient(circle at top right, rgba(179, 19, 18, .06), transparent 28%),
                linear-gradient(180deg, #f8fafc, #f1f5f9);
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            color: var(--user-dark);
            overflow-x: hidden;
        }

        a {
            text-decoration: none;
        }

        /* =========================
           SIDEBAR
        ========================= */
       /* =========================
   SIDEBAR
========================= */
.user-sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: var(--sidebar-width);
    height: 100vh;
    z-index: 1040;
    display: flex;
    flex-direction: column;
    overflow: hidden;

    background:
        radial-gradient(circle at top right, rgba(179, 19, 18, .18), transparent 34%),
        radial-gradient(circle at bottom left, rgba(230, 57, 70, .10), transparent 30%),
        linear-gradient(180deg, #fff7f7 0%, #fff 42%, #fff8f8 100%);

    border-right: 1px solid rgba(179, 19, 18, .12);
    box-shadow: 18px 0 45px rgba(15, 23, 42, .06);
}

.user-sidebar::before {
    content: "";
    position: absolute;
    inset: 0;
    background-image:
        linear-gradient(to right, rgba(179, 19, 18, .035) 1px, transparent 1px),
        linear-gradient(to bottom, rgba(179, 19, 18, .035) 1px, transparent 1px);
    background-size: 32px 32px;
    opacity: .55;
    pointer-events: none;
}

.user-sidebar::after {
    content: "";
    position: absolute;
    right: -70px;
    top: 120px;
    width: 180px;
    height: 180px;
    border-radius: 50%;
    background: rgba(179, 19, 18, .08);
    filter: blur(2px);
    pointer-events: none;
}

.sidebar-brand {
    position: relative;
    z-index: 2;
    padding: 26px 22px 24px;
    border-bottom: 1px solid rgba(179, 19, 18, .10);
    overflow: hidden;

    background:
        linear-gradient(135deg, rgba(255,255,255,.88), rgba(255,241,241,.68));
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
}

.sidebar-brand::before {
    content: "";
    position: absolute;
    right: -54px;
    top: -54px;
    width: 150px;
    height: 150px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(179,19,18,.16), transparent 70%);
}

.brand-inner {
    position: relative;
    z-index: 2;
    display: flex;
    align-items: center;
    gap: 13px;
}

.brand-logo {
    width: 52px;
    height: 52px;
    border-radius: 18px;
    background:
        linear-gradient(135deg, #fff, #ffe8e8);
    color: var(--user-red);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 27px;
    flex-shrink: 0;
    border: 1px solid rgba(179, 19, 18, .18);
    box-shadow: 0 12px 26px rgba(179, 19, 18, .13);
}

.brand-title {
    display: block;
    color: var(--user-red);
    font-size: 18px;
    line-height: 1.1;
    font-weight: 900;
    letter-spacing: .2px;
}

.brand-subtitle {
    display: block;
    color: #64748b;
    font-size: 12.5px;
    margin-top: 5px;
    font-weight: 600;
}

.sidebar-menu {
    position: relative;
    z-index: 2;
    padding: 24px 14px;
    flex: 1;
    overflow-y: auto;
}

.sidebar-link {
    position: relative;
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 15px 16px;
    margin-bottom: 11px;
    border-radius: 18px;
    color: #334155;
    font-weight: 750;
    transition: .22s ease;
    overflow: hidden;

    background: rgba(255,255,255,.45);
    border: 1px solid rgba(255,255,255,.45);
}

.sidebar-link::before {
    content: "";
    position: absolute;
    inset: 0;
    background:
        linear-gradient(90deg, rgba(179, 19, 18, .14), rgba(230, 57, 70, .06));
    opacity: 0;
    transition: .22s ease;
}

.sidebar-link:hover::before,
.sidebar-link.active::before {
    opacity: 1;
}

.sidebar-link:hover,
.sidebar-link.active {
    color: var(--user-red);
    transform: translateX(3px);
    border-color: rgba(179, 19, 18, .10);
    box-shadow: 0 10px 24px rgba(179, 19, 18, .08);
}

.sidebar-link.active {
    background:
        linear-gradient(90deg, rgba(179, 19, 18, .12), rgba(255,255,255,.74));
}

.sidebar-link.active::after {
    content: "";
    position: absolute;
    right: 13px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--user-red);
    box-shadow: 0 0 0 6px rgba(179, 19, 18, .10);
}

.sidebar-link i,
.sidebar-link span {
    position: relative;
    z-index: 2;
}

.sidebar-link i {
    width: 26px;
    height: 26px;
    border-radius: 10px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 17px;
    color: inherit;
}

.sidebar-link.active i {
    background: rgba(179, 19, 18, .10);
}

.sidebar-spacer {
    height: 16px;
}

        /* =========================
           MAIN AREA
        ========================= */
        .user-main {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
        }

        .user-topbar {
            height: var(--topbar-height);
            background: rgba(255, 255, 255, .92);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border-bottom: 1px solid var(--user-border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 28px;
            position: sticky;
            top: 0;
            z-index: 1030;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .sidebar-toggle {
            display: none;
            width: 42px;
            height: 42px;
            border: 1px solid var(--user-border);
            background: #fff;
            border-radius: 14px;
            color: var(--user-red);
            font-size: 22px;
        }

        .topbar-title strong {
            display: block;
            color: var(--user-dark);
            font-size: 16px;
            font-weight: 900;
        }

        .topbar-title span {
            display: block;
            color: var(--user-muted);
            font-size: 13px;
            margin-top: 2px;
        }

        .topbar-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .topbar-chip {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border: 1px solid #bbf7d0;
            background: #ecfdf5;
            color: #047857;
            border-radius: 999px;
            padding: 8px 12px;
            font-size: 13px;
            font-weight: 800;
        }

        .user-dropdown-btn {
            border: 1px solid var(--user-border);
            background: #fff;
            color: var(--user-dark);
            border-radius: 14px;
            padding: 9px 12px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 9px;
        }

        .user-avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--user-red), var(--user-red-2));
            color: #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .dropdown-menu {
            border: 0;
            border-radius: 18px;
            box-shadow: 0 18px 45px rgba(15, 23, 42, .14);
            padding: 10px;
        }

        .dropdown-item {
            border-radius: 12px;
            padding: 10px 12px;
            font-weight: 600;
        }

        .dropdown-item i {
            width: 22px;
        }

        .dropdown-item.text-danger:hover {
            background: rgba(179, 19, 18, .08);
            color: var(--user-red) !important;
        }

        .content-wrapper {
            padding: 28px;
        }

        .btn-bawaslu {
            background: linear-gradient(90deg, var(--user-red), var(--user-red-2));
            color: #fff;
            border: 0;
            border-radius: 12px;
            font-weight: 700;
            box-shadow: 0 12px 26px rgba(179, 19, 18, .18);
        }

        .btn-bawaslu:hover {
            color: #fff;
            transform: translateY(-1px);
            box-shadow: 0 16px 32px rgba(179, 19, 18, .24);
        }

        .content-card,
        .table-card,
        .card-stat {
            border: 0;
            border-radius: 22px;
            box-shadow: 0 14px 35px rgba(15, 23, 42, .06);
            overflow: hidden;
        }

        .page-title {
            font-weight: 900;
            color: var(--user-dark);
        }

        .sidebar-overlay {
            display: none;
        }

        /* =========================
           RESPONSIVE
        ========================= */
        @media (max-width: 991.98px) {
            .user-sidebar {
                transform: translateX(-100%);
                transition: .25s ease;
            }

            .user-sidebar.show {
                transform: translateX(0);
            }

            .user-main {
                margin-left: 0;
            }

            .sidebar-toggle {
                display: inline-flex;
                align-items: center;
                justify-content: center;
            }

            .sidebar-overlay {
                position: fixed;
                inset: 0;
                background: rgba(15, 23, 42, .50);
                backdrop-filter: blur(4px);
                -webkit-backdrop-filter: blur(4px);
                z-index: 1035;
                display: none;
            }

            .sidebar-overlay.show {
                display: block;
            }

            .topbar-chip {
                display: none;
            }
        }

        @media (max-width: 575.98px) {
            .user-topbar {
                padding: 0 16px;
            }

            .content-wrapper {
                padding: 20px 16px;
            }

            .topbar-title span {
                display: none;
            }

            .user-dropdown-btn .user-name {
                display: none;
            }
        }
    </style>

    <?= $this->renderSection('styles') ?>
</head>
<body>

<?php
$currentPath = uri_string();

$isDashboard = $currentPath === 'user' || $currentPath === 'user/dashboard';
$isDetection = str_starts_with($currentPath, 'user/detections');
$isHistory   = str_starts_with($currentPath, 'user/history');
$isEducation = str_starts_with($currentPath, 'user/education');
$isProfile   = str_starts_with($currentPath, 'user/profile');

$fullName = session()->get('full_name') ?? 'User';
$initial = strtoupper(substr(trim($fullName), 0, 1));
?>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<aside class="user-sidebar" id="userSidebar">
    <div class="sidebar-brand">
        <div class="brand-inner">
            <div class="brand-logo">
                <i class="bi bi-shield-check"></i>
            </div>

            <div>
                <span class="brand-title">BAWASLU</span>
                <span class="brand-subtitle">Deepfake Detection</span>
            </div>
        </div>
    </div>

    <nav class="sidebar-menu">
        <a href="<?= base_url('user/dashboard') ?>" class="sidebar-link <?= $isDashboard ? 'active' : '' ?>">
            <i class="bi bi-speedometer2"></i>
            <span>Dashboard</span>
        </a>

        <a href="<?= base_url('user/detections/create') ?>" class="sidebar-link <?= $isDetection ? 'active' : '' ?>">
            <i class="bi bi-cloud-arrow-up"></i>
            <span>Deteksi Video</span>
        </a>

        <a href="<?= base_url('user/history') ?>" class="sidebar-link <?= $isHistory ? 'active' : '' ?>">
            <i class="bi bi-clock-history"></i>
            <span>Riwayat Deteksi</span>
        </a>

        <a href="<?= base_url('user/education') ?>" class="sidebar-link <?= $isEducation ? 'active' : '' ?>">
            <i class="bi bi-journal-text"></i>
            <span>Edukasi Deepfake</span>
        </a>

        <div class="sidebar-spacer"></div>

        <a href="<?= base_url('user/profile') ?>" class="sidebar-link <?= $isProfile ? 'active' : '' ?>">
            <i class="bi bi-person-circle"></i>
            <span>Profil</span>
        </a>
    </nav>
</aside>

<main class="user-main">
    <header class="user-topbar">
        <div class="topbar-left">
            <button class="sidebar-toggle" type="button" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>

            <div class="topbar-title">
                <strong>Sistem Deteksi Deepfake</strong>
                <span>Panel Masyarakat</span>
            </div>
        </div>

        <div class="topbar-actions">
            <!-- <div class="topbar-chip">
                <i class="bi bi-cpu-fill"></i>
                AI Model Ready
            </div> -->

            <div class="dropdown">
                <button class="user-dropdown-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <span class="user-avatar"><?= esc($initial) ?></span>
                    <span class="user-name"><?= esc($fullName) ?></span>
                </button>

                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a class="dropdown-item" href="<?= base_url('user/profile') ?>">
                            <i class="bi bi-person"></i>
                            Profil Saya
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?= base_url('user/history') ?>">
                            <i class="bi bi-clock-history"></i>
                            Riwayat Deteksi
                        </a>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item text-danger" href="<?= base_url('logout') ?>">
                            <i class="bi bi-box-arrow-right"></i>
                            Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <section class="content-wrapper">
        <?= $this->include('partials/alert') ?>
        <?= $this->renderSection('content') ?>
    </section>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    const sidebarToggle = document.getElementById('sidebarToggle');
    const userSidebar = document.getElementById('userSidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    function openSidebar() {
        userSidebar.classList.add('show');
        sidebarOverlay.classList.add('show');
    }

    function closeSidebar() {
        userSidebar.classList.remove('show');
        sidebarOverlay.classList.remove('show');
    }

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', openSidebar);
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', closeSidebar);
    }

    document.querySelectorAll('.sidebar-link').forEach(function (link) {
        link.addEventListener('click', function () {
            if (window.innerWidth <= 991) {
                closeSidebar();
            }
        });
    });
</script>

<?= $this->renderSection('scripts') ?>

</body>
</html>