<?= $this->extend('layouts/user') ?>

<?= $this->section('styles') ?>

<style>
    :root {
        --dash-red: #b31312;
        --dash-red-2: #e63946;
        --dash-dark: #111827;
        --dash-muted: #6b7280;
        --dash-border: #e5e7eb;
        --dash-soft: #f8fafc;
        --dash-blue: #2563eb;
        --dash-green: #059669;
        --dash-orange: #f59e0b;
        --dash-purple: #7c3aed;
    }

    .dashboard-hero {
        position: relative;
        overflow: hidden;
        border-radius: 28px;
        background:
            linear-gradient(135deg, rgba(179, 19, 18, .98), rgba(31, 31, 31, .98)),
            radial-gradient(circle at top right, rgba(255,255,255,.18), transparent 34%);
        color: #fff;
        padding: 30px;
        margin-bottom: 24px;
        box-shadow: 0 22px 55px rgba(15, 23, 42, .16);
    }

    .dashboard-hero::before {
        content: "";
        position: absolute;
        right: -90px;
        top: -90px;
        width: 260px;
        height: 260px;
        border-radius: 50%;
        background: rgba(255,255,255,.10);
    }

    .dashboard-hero::after {
        content: "";
        position: absolute;
        right: 90px;
        bottom: -120px;
        width: 300px;
        height: 300px;
        border-radius: 50%;
        background: rgba(255,255,255,.07);
    }

    .dashboard-hero-content {
        position: relative;
        z-index: 2;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 24px;
    }

    .dashboard-hero h3 {
        font-weight: 900;
        margin-bottom: 8px;
        color: #fff;
    }

    .dashboard-hero p {
        color: rgba(255,255,255,.82);
        margin-bottom: 0;
        line-height: 1.7;
        max-width: 720px;
    }

    .hero-action {
        display: inline-flex;
        align-items: center;
        gap: 9px;
        border: 0;
        border-radius: 16px;
        background: #fff;
        color: var(--dash-red);
        padding: 13px 18px;
        font-weight: 800;
        text-decoration: none;
        box-shadow: 0 16px 34px rgba(0,0,0,.18);
        transition: .25s ease;
        white-space: nowrap;
    }

    .hero-action:hover {
        color: var(--dash-red);
        transform: translateY(-2px);
    }

    .stat-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 18px;
        margin-bottom: 24px;
    }

    .dash-stat-card {
        position: relative;
        overflow: hidden;
        border: 0;
        border-radius: 24px;
        background: #fff;
        padding: 22px;
        min-height: 132px;
        box-shadow: 0 16px 42px rgba(15, 23, 42, .07);
    }

    .dash-stat-card::before {
        content: "";
        position: absolute;
        right: -42px;
        top: -42px;
        width: 128px;
        height: 128px;
        border-radius: 50%;
        opacity: .13;
    }

    .dash-stat-card.total::before {
        background: var(--dash-blue);
    }

    .dash-stat-card.real::before {
        background: var(--dash-green);
    }

    .dash-stat-card.fake::before {
        background: var(--dash-red);
    }

    .dash-stat-card.failed::before {
        background: var(--dash-orange);
    }

    .stat-top {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 14px;
        position: relative;
        z-index: 2;
    }

    .stat-label {
        color: var(--dash-muted);
        font-size: 13px;
        font-weight: 700;
        margin-bottom: 8px;
    }

    .stat-value {
        font-size: 34px;
        line-height: 1;
        font-weight: 900;
        color: var(--dash-dark);
    }

    .stat-icon {
        width: 54px;
        height: 54px;
        border-radius: 18px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 26px;
        flex-shrink: 0;
    }

    .stat-icon.total {
        background: rgba(37, 99, 235, .10);
        color: var(--dash-blue);
    }

    .stat-icon.real {
        background: rgba(5, 150, 105, .10);
        color: var(--dash-green);
    }

    .stat-icon.fake {
        background: rgba(179, 19, 18, .10);
        color: var(--dash-red);
    }

    .stat-icon.failed {
        background: rgba(245, 158, 11, .13);
        color: var(--dash-orange);
    }

    .stat-footer {
        margin-top: 18px;
        position: relative;
        z-index: 2;
    }

    .stat-progress {
        height: 7px;
        background: #edf2f7;
        border-radius: 999px;
        overflow: hidden;
    }

    .stat-progress span {
        display: block;
        height: 100%;
        border-radius: 999px;
    }

    .total .stat-progress span {
        background: var(--dash-blue);
    }

    .real .stat-progress span {
        background: var(--dash-green);
    }

    .fake .stat-progress span {
        background: var(--dash-red);
    }

    .failed .stat-progress span {
        background: var(--dash-orange);
    }

    .dashboard-grid {
        display: grid;
        grid-template-columns: .85fr 1.15fr;
        gap: 22px;
        margin-bottom: 24px;
    }

    .dash-card {
        border: 0;
        border-radius: 24px;
        background: #fff;
        box-shadow: 0 18px 45px rgba(15, 23, 42, .07);
        overflow: hidden;
    }

    .dash-card-header {
        padding: 20px 22px;
        border-bottom: 1px solid var(--dash-border);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
    }

    .dash-card-header h5 {
        font-weight: 900;
        color: var(--dash-dark);
        margin-bottom: 0;
    }

    .guide-list {
        padding: 22px;
    }

    .guide-item {
        display: flex;
        gap: 14px;
        align-items: flex-start;
        margin-bottom: 18px;
    }

    .guide-item:last-child {
        margin-bottom: 0;
    }

    .guide-icon {
        width: 48px;
        height: 48px;
        border-radius: 16px;
        background: rgba(179, 19, 18, .09);
        color: var(--dash-red);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        flex-shrink: 0;
    }

    .guide-item strong {
        display: block;
        font-size: 15px;
        color: var(--dash-dark);
        margin-bottom: 4px;
    }

    .guide-item span {
        display: block;
        color: var(--dash-muted);
        font-size: 13.5px;
        line-height: 1.6;
    }

    .education-box {
        margin: 0 22px 22px;
        border-radius: 18px;
        background:
            linear-gradient(135deg, rgba(179, 19, 18, .08), rgba(230, 57, 70, .04));
        border: 1px solid rgba(179, 19, 18, .13);
        padding: 18px;
    }

    .education-box h6 {
        font-weight: 900;
        color: var(--dash-dark);
        margin-bottom: 8px;
    }

    .education-box p {
        color: var(--dash-muted);
        font-size: 13.5px;
        line-height: 1.7;
        margin-bottom: 14px;
    }

    .table-dashboard {
        margin-bottom: 0;
    }

    .table-dashboard thead th {
        background: var(--dash-soft);
        color: #334155;
        font-size: 13px;
        font-weight: 800;
        border-bottom: 1px solid var(--dash-border);
        padding: 14px 18px;
        white-space: nowrap;
    }

    .table-dashboard tbody td {
        padding: 15px 18px;
        vertical-align: middle;
        border-bottom: 1px solid #eef2f7;
    }

    .video-cell {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 230px;
    }

    .video-icon {
        width: 42px;
        height: 42px;
        border-radius: 14px;
        background: rgba(179, 19, 18, .09);
        color: var(--dash-red);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        flex-shrink: 0;
    }

    .video-name {
        font-weight: 800;
        color: var(--dash-dark);
        max-width: 220px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .video-id {
        font-size: 12px;
        color: var(--dash-muted);
    }

    .badge-result {
        border-radius: 999px;
        padding: 7px 11px;
        font-weight: 800;
        font-size: 11.5px;
    }

    .quick-section {
        display: grid;
        grid-template-columns: 1.2fr .8fr;
        gap: 22px;
    }

    .insight-card {
        border: 0;
        border-radius: 24px;
        background: #fff;
        box-shadow: 0 18px 45px rgba(15, 23, 42, .07);
        padding: 22px;
    }

    .insight-card h5 {
        font-weight: 900;
        color: var(--dash-dark);
        margin-bottom: 14px;
    }

    .insight-row {
        margin-bottom: 14px;
    }

    .insight-row:last-child {
        margin-bottom: 0;
    }

    .insight-label {
        display: flex;
        justify-content: space-between;
        color: var(--dash-muted);
        font-size: 13px;
        font-weight: 700;
        margin-bottom: 7px;
    }

    .insight-bar {
        height: 9px;
        background: #edf2f7;
        border-radius: 999px;
        overflow: hidden;
    }

    .insight-bar span {
        display: block;
        height: 100%;
        border-radius: 999px;
    }

    .cta-card {
        position: relative;
        overflow: hidden;
        border-radius: 24px;
        background:
            linear-gradient(135deg, rgba(179,19,18,.98), rgba(17,24,39,.98));
        color: #fff;
        padding: 24px;
        box-shadow: 0 18px 45px rgba(179, 19, 18, .18);
    }

    .cta-card::before {
        content: "";
        position: absolute;
        right: -60px;
        top: -60px;
        width: 180px;
        height: 180px;
        border-radius: 50%;
        background: rgba(255,255,255,.12);
    }

    .cta-card-content {
        position: relative;
        z-index: 2;
    }

    .cta-card h5 {
        font-weight: 900;
        color: #fff;
        margin-bottom: 9px;
    }

    .cta-card p {
        color: rgba(255,255,255,.82);
        line-height: 1.7;
        font-size: 13.5px;
        margin-bottom: 18px;
    }

    .cta-card .btn {
        border-radius: 14px;
        font-weight: 800;
    }

    @media (max-width: 1199.98px) {
        .stat-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .dashboard-grid,
        .quick-section {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 575.98px) {
        .dashboard-hero-content {
            flex-direction: column;
            align-items: flex-start;
        }

        .stat-grid {
            grid-template-columns: 1fr;
        }

        .dash-card-header {
            flex-direction: column;
            align-items: flex-start;
        }

        .table-dashboard thead {
            display: none;
        }

        .table-dashboard,
        .table-dashboard tbody,
        .table-dashboard tr,
        .table-dashboard td {
            display: block;
            width: 100%;
        }

        .table-dashboard tbody tr {
            padding: 14px 16px;
            border-bottom: 1px solid #eef2f7;
        }

        .table-dashboard tbody td {
            padding: 7px 0;
            border-bottom: 0;
        }
    }
</style>

<?= $this->endSection() ?>

<?= $this->section('content') ?>

<?php
$statusBadge = static function (?string $status): string {
    return match ($status) {
        'pending' => 'warning',
        'processing' => 'info',
        'completed' => 'success',
        'failed' => 'danger',
        'reviewed' => 'primary',
        default => 'secondary',
    };
};

$labelBadge = static function (?string $label): string {
    return match ($label) {
        'REAL' => 'success',
        'DEEPFAKE' => 'danger',
        'UNKNOWN' => 'secondary',
        default => 'secondary',
    };
};

$totalVideos   = (int) ($total_videos ?? 0);
$totalReal     = (int) ($total_real ?? 0);
$totalDeepfake = (int) ($total_deepfake ?? 0);
$totalFailed   = (int) ($total_failed ?? 0);

$realPercent = $totalVideos > 0 ? round(($totalReal / $totalVideos) * 100, 1) : 0;
$deepfakePercent = $totalVideos > 0 ? round(($totalDeepfake / $totalVideos) * 100, 1) : 0;
$failedPercent = $totalVideos > 0 ? round(($totalFailed / $totalVideos) * 100, 1) : 0;

$latestRows = array_slice($latest_data ?? [], 0, 5);
?>

<div class="dashboard-hero">
    <div class="dashboard-hero-content">
        <div>
            <h3>Dashboard User</h3>
            <p>
                Selamat datang, <?= esc(session()->get('full_name') ?? 'User') ?>.
                Pantau ringkasan deteksi video dan lakukan analisis deepfake dari satu halaman.
            </p>
        </div>

        <!-- <a href="<?= base_url('user/detections/create') ?>" class="hero-action">
            <i class="bi bi-cloud-arrow-up"></i>
            Deteksi Video
        </a> -->
    </div>
</div>

<div class="stat-grid">
    <div class="dash-stat-card total">
        <div class="stat-top">
            <div>
                <div class="stat-label">Total Video</div>
                <div class="stat-value"><?= esc($totalVideos) ?></div>
            </div>
            <div class="stat-icon total">
                <i class="bi bi-camera-video"></i>
            </div>
        </div>
        <div class="stat-footer">
            <div class="stat-progress">
                <span style="width: <?= $totalVideos > 0 ? '100' : '0' ?>%;"></span>
            </div>
        </div>
    </div>

    <div class="dash-stat-card real">
        <div class="stat-top">
            <div>
                <div class="stat-label">Video REAL</div>
                <div class="stat-value text-success"><?= esc($totalReal) ?></div>
            </div>
            <div class="stat-icon real">
                <i class="bi bi-check-circle"></i>
            </div>
        </div>
        <div class="stat-footer">
            <div class="stat-progress">
                <span style="width: <?= esc($realPercent) ?>%;"></span>
            </div>
        </div>
    </div>

    <div class="dash-stat-card fake">
        <div class="stat-top">
            <div>
                <div class="stat-label">Video DEEPFAKE</div>
                <div class="stat-value text-danger"><?= esc($totalDeepfake) ?></div>
            </div>
            <div class="stat-icon fake">
                <i class="bi bi-exclamation-triangle"></i>
            </div>
        </div>
        <div class="stat-footer">
            <div class="stat-progress">
                <span style="width: <?= esc($deepfakePercent) ?>%;"></span>
            </div>
        </div>
    </div>

    <div class="dash-stat-card failed">
        <div class="stat-top">
            <div>
                <div class="stat-label">Proses Gagal</div>
                <div class="stat-value text-warning"><?= esc($totalFailed) ?></div>
            </div>
            <div class="stat-icon failed">
                <i class="bi bi-x-circle"></i>
            </div>
        </div>
        <div class="stat-footer">
            <div class="stat-progress">
                <span style="width: <?= esc($failedPercent) ?>%;"></span>
            </div>
        </div>
    </div>
</div>

<div class="dashboard-grid">
    <div class="dash-card">
        <div class="dash-card-header">
            <h5>Panduan Singkat</h5>
        </div>

        <div class="guide-list">
            <div class="guide-item">
                <div class="guide-icon">
                    <i class="bi bi-upload"></i>
                </div>
                <div>
                    <strong>1. Upload Video</strong>
                    <span>Pilih video yang ingin dianalisis melalui menu Deteksi Video.</span>
                </div>
            </div>

            <div class="guide-item">
                <div class="guide-icon">
                    <i class="bi bi-cpu"></i>
                </div>
                <div>
                    <strong>2. Proses Model AI</strong>
                    <span>Sistem mengirim video ke Flask API untuk diproses oleh model deepfake.</span>
                </div>
            </div>

            <div class="guide-item">
                <div class="guide-icon">
                    <i class="bi bi-bar-chart-line"></i>
                </div>
                <div>
                    <strong>3. Lihat Hasil</strong>
                    <span>Hasil klasifikasi akan ditampilkan sebagai REAL atau DEEPFAKE.</span>
                </div>
            </div>
        </div>

        <div class="education-box">
            <h6>
                <i class="bi bi-journal-text me-1"></i>
                Edukasi Deepfake
            </h6>
            <p>
                Pelajari ciri-ciri umum video manipulatif agar lebih berhati-hati sebelum membagikan informasi.
            </p>
            <a href="<?= base_url('user/education') ?>" class="btn btn-outline-danger w-100">
                Baca Edukasi
            </a>
        </div>
    </div>

    <div class="dash-card">
        <div class="dash-card-header">
            <h5>Riwayat Terbaru</h5>
            <a href="<?= base_url('user/history') ?>" class="btn btn-sm btn-outline-primary">
                Lihat Semua
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle table-dashboard">
                <thead>
                    <tr>
                        <th>Video</th>
                        <th>Hasil</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th width="90">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (! empty($latestRows)) : ?>
                        <?php foreach ($latestRows as $row) : ?>
                            <?php
                            $label = $row['predicted_label'] ?? 'UNKNOWN';
                            $status = $row['status'] ?? 'pending';
                            ?>
                            <tr>
                                <td>
                                    <div class="video-cell">
                                        <div class="video-icon">
                                            <i class="bi bi-file-earmark-play"></i>
                                        </div>
                                        <div>
                                            <div class="video-name"><?= esc($row['original_filename'] ?? '-') ?></div>
                                            <div class="video-id">ID: <?= esc($row['id'] ?? '-') ?></div>
                                        </div>
                                    </div>
                                </td>

                                <td>
                                    <span class="badge badge-result text-bg-<?= esc($labelBadge($label)) ?>">
                                        <?= esc($label) ?>
                                    </span>
                                </td>

                                <td>
                                    <span class="badge text-bg-<?= esc($statusBadge($status)) ?>">
                                        <?= esc($status) ?>
                                    </span>
                                </td>

                                <td><?= esc($row['created_at'] ?? '-') ?></td>

                                <td>
                                    <a href="<?= base_url('user/history/detail/' . ($row['id'] ?? 0)) ?>" class="btn btn-sm btn-outline-primary">
                                        Detail
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-5">
                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                Belum ada riwayat deteksi.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="quick-section">
    <div class="insight-card">
        <h5>Ringkasan Persentase</h5>

        <div class="insight-row">
            <div class="insight-label">
                <span>REAL</span>
                <span><?= esc($realPercent) ?>%</span>
            </div>
            <div class="insight-bar">
                <span style="width: <?= esc($realPercent) ?>%; background: var(--dash-green);"></span>
            </div>
        </div>

        <div class="insight-row">
            <div class="insight-label">
                <span>DEEPFAKE</span>
                <span><?= esc($deepfakePercent) ?>%</span>
            </div>
            <div class="insight-bar">
                <span style="width: <?= esc($deepfakePercent) ?>%; background: var(--dash-red);"></span>
            </div>
        </div>

        <div class="insight-row">
            <div class="insight-label">
                <span>Gagal</span>
                <span><?= esc($failedPercent) ?>%</span>
            </div>
            <div class="insight-bar">
                <span style="width: <?= esc($failedPercent) ?>%; background: var(--dash-orange);"></span>
            </div>
        </div>
    </div>

    <div class="cta-card">
        <div class="cta-card-content">
            <h5>Mulai Analisis Video Baru</h5>
            <p>
                Upload video terbaru untuk mendapatkan hasil klasifikasi dari model deepfake.
            </p>
            <a href="<?= base_url('user/detections/create') ?>" class="btn btn-light w-100">
                <i class="bi bi-cloud-arrow-up me-1"></i>
                Upload Video
            </a>
        </div>
    </div>
</div>

<?= $this->endSection() ?>